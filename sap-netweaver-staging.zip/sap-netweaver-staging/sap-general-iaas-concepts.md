---



copyright:
  years: 2017, 2018
lastupdated: "2018-01-25"


---

{:shortdesc: .shortdesc}
{:codeblock: .codeblock}
{:screen: .screen}
{:new_window: target="_blank"}
{:pre: .pre}
{:table: .aria-labeledby="caption"}

# SAP NetWeaver on IBM Cloud IaaS Overview
An Infrastructure-as-a-server (IaaS) environment consists of many components: data center, compute, connectivity, storage, and network. 

## Data centers

With data centers across North and South America, Europe, Asia, and Australia, you can provision cloud resources where (and when) you need them. Each data center is connected to the {{site.data.keyword.cloud_notm}} global private network, making data transfers faster and more efficient anywhere in the world.

See [Data Centers](https://www.ibm.com/cloud-computing/bluemix/data-centers){: new_window} for more information on the {{site.data.keyword.cloud_notm}} data centers and points of presence (PoPs).

## Bare metal servers

{{site.data.keyword.baremetal_long}} are physical servers with limited customization capabilities. The servers are dedicated for your use, or your customer's, and not shared in any part, including server resources, with other {{site.data.keyword.cloud_notm}} customers. These servers are managed by you, or your customer, and are provisioned without a hypervisor.

Because customization is limited on bare metal servers, faster provisioning times of between 1 to 4 hours are obtainable. Quick provisioning is helpful when you are trying to get an app to market before the competition.

You are offered an array of RAM and CPU combinations as the SAP-certified servers have a pre-configured amount of RAM and number of CPUs. The combination *cannot* be changed during the ordering process or through a support ticket after servers are deployed.

If your project requires a virtualization layer, the SAP NetWeaver offering includes the option to order {{site.data.keyword.baremetal_short}} that are deployed with VMware ESXi. The ESX instance is under your full control, as it is deployed in your data center. The system is fully configured regarding networking (any further configuration, such as storage, is up to you). It is highly recommended that you have a person with an understanding of ESX administration on staff to successfully start your project.

See [About bare metal servers](https://console.bluemix.net/docs/bare-metal/index.html#about-bare-metal-servers) for more information on bare metal servers. 

## Operating systems

You need to consult [SAP Note 2414097](https://launchpad.support.sap.com/#/notes/2414097){: new window} for a list of guest operating systems (OS) to deploy SAP NetWeaver-based systems. An SAP S-user ID is required to access the SAP Note. Licensing for the guest OS is covered by you.

## Network connectivity

Virtual private network (VPN) connectivity to the {{site.data.keyword.cloud_notm}} Virtual Cloud Network is granted automatically when your {{site.data.keyword.cloud_notm}} account is set up. By default, your server has a public and private IP address. If you want your server to be private, you can either turn off the public interface after your server is provisioned or order your server as private. See [Getting started with Virtual Private Networking](https://console.bluemix.net/docs/infrastructure/iaas-vpn/getting-started.html#getting-started-with-virtual-private-networking-vpn-) for more information on {{site.data.keyword.cloud_notm}} VPN.

## Storage
{: #storage}

Local storage is provided with your {{site.data.keyword.baremetal_short}} and uses the {{site.data.keyword.cloud_notm}} private network virtual LAN (VLAN) to help provide enterprise-grade security while not obstructing administrator access. It is ideal for storage-intensive applications with high I/O needs, such as an OS, and database and application software. SAP NetWeaver server disk space depends on how your server is configured. Contact [{{site.data.keyword.cloud_notm}} Support](https://console.bluemix.net/docs/support/index.html#getting-customer-support) for extension options if the local storage on your server is insufficient for your workload.

There are two types of storage for {{site.data.keyword.cloud_notm}}-block and file-from which to choose to perform backups and restores for SAP NetWeaver. Both types use input/output operations per second (IOPS), which are used to determine storage needs. IOPS are measured based on 16 KB block size with a 50/50 read/write mix. To achieve maximum IOPS on a volume, adequate network resources need to be in place. Other considerations include private network usage outside of storage and host side, and application-specific tunings (for example, IP stacks and queue depths). See [Getting started with Block Storage](https://console.bluemix.net/docs/infrastructure/BlockStorage/index.html#getting-started-with-block-storage) and [Getting started with File Storage](https://console.bluemix.net/docs/infrastructure/FileStorage/index.html#getting-started-with-file-storage) for more information on storage tiers and performance.

{{site.data.keyword.cloud_notm}} also offers Network Attached Storage (NAS) if you are looking to for a quick, cost-efficient, backup solution for your devices. NAS is compatible with
  * Red Hat Enterprise Linux (RHEL) for SAP Business Applications 6.X OS
  * File Transfer Protocol (FTP) with both Parallels Plesk Panel and cPanel@WHM
  * Microsoft Windows Server through standard Windows procedures using the Common Internet File System (CIFS) Protocol
  
NAS and FTP storage are billed monthly and are available in various storage sizes. You can primarily interact with your NAS and FTP storage within the command line or terminal with the OS, or through point-and-click interactions on the panels within the {{site.data.keyword.cloud_notm}} infrastructure customer portal.

More information on NAS in an {{site.data.keyword.cloud_notm}} environment can be found under [Getting started with NAS](https://console.bluemix.net/docs/infrastructure/network-attached-storage/index.html#getting-started-with-nas).

## Deployment and management

{{site.data.keyword.cloud_notm}} {{site.data.keyword.baremetal_short}} are deployed through the {{site.data.keyword.cloud_notm}} infrastructure customer portal or API after you create your {{site.data.keyword.cloud_notm}} customer account. The servers can be managed through the customer portal, API, or command line interface (CLI). More information can be found under [About bare metal servers](https://console.bluemix.net/docs/bare-metal/index.html#about-bare-metal-servers).

## Support

[{{site.data.keyword.cloud_notm}} Customer Support](https://console.bluemix.net/docs/support/index.html#getting-customer-support) handles any support questions and issues that might arise using various outlets, including chat, phone, and ticket-based support. Customer support is offered at no cost to all {{site.data.keyword.cloud_notm}} customers and covers most tickets that are placed each day. See [Getting Customer Support](https://console.bluemix.net./docs/support/index.html#getting-customer-support) for more information.
