---



copyright:
  years: 2017, 2018
lastupdated: "2018-01-25"


---

{:shortdesc: .shortdesc}
{:codeblock: .codeblock}
{:screen: .screen}
{:new_window: target="_blank"}
{:pre: .pre}
{:table: .aria-labeledby="caption"}

# Support

[{{site.data.keyword.cloud}} Customer Support](https://console.bluemix.net/docs/get-support/howtogetsupport.html#getting-customer-support) handles any support questions and issues that may arise using a variety of outlets, including chat, phone, and ticket-based support. It's offered at no cost to all {{site.data.keyword.cloud_notm}}customers and covers most tickets that are placed each day.

Visit [Getting Customer Support](https://console.bluemix.net/docs/get-support/howtogetsupport.html#getting-customer-support) for more information.
