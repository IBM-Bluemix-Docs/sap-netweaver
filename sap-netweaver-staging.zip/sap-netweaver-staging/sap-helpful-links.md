---



copyright:
  years: 2017
lastupdated: "2017-12-01"


---

{:shortdesc: .shortdesc}
{:codeblock: .codeblock}
{:screen: .screen}
{:new_window: target="_blank"}
{:pre: .pre}
{:table: .aria-labeledby="caption"}

# Helpful links

*	Explore the SAP portfolio, http://go.sap.com/solution.html
*	What is IBM Cloud?, https://www.ibm.com/cloud-computing/
*	Getting started with IBM Cloud, https://www.ibm.com/cloud-computing/bluemix/getting-started
*	SAP installation and upgrade information, http://help.sap.com/nw75#section2
*	How to set up an SAP S-user ID, https://www.sapappsdevelopmentpartnercenter.com/en/faq/program-faqs_2/how-to-receive-an-S-user-to%20access-the-s_77/
*	SAP NetWeaver Help, http://help.sap.com/netweaver
*	SAP Installation Guides, https://service.sap.com/instguides (requires an SAP S-user ID)
*	SAP Notes, https://support.sap.com/notes (requires an SAP S-user ID)
*	IBM Cloud datacenter information, https://www.ibm.com/cloud-computing/bluemix/data-centers
*	Bare metal server information, http://knowledgelayer.softlayer.com/topic/bare-metal-server
*	Customer Portal, https://control.softlayer.com
*	IBM Cloud VPN information, http://knowledgelayer.softlayer.com/procedure/getting-started-softlayer-vpn
*	IBM Cloud Support, https://console.bluemix.net/docs/support
*	Endurance for block and file storage information, https://knowledgelayer.softlayer.com/topic/endurance-storage
*	Network attached storage information, https://knowledgelayer.softlayer.com/topic/nas
*	SAP Support, https://support.sap.com/home.html
*	SAP Product Availability Matrix, https://apps.support.sap.com/sap/support/pam
*	SAP installation guides, https://support.sap.com/software/installations.html (requires an SAP S-user ID)
*	SAP Help Portal, http://help.sap.com/ (requires an SAP S-user ID
*	SAP Quick Sizer, http://service.sap.com/quicksizer
*	SAP Sales and Distribution benchmarking, http://go.sap.com/solution/benchmark.html
*	SAP Cloud Benchmark (certification documents), http://global.sap.com/campaigns/benchmark/appbm_cloud.epx
*	SAP Service Marketplace, https://websmp201.sap-ag.de/
*	How to log in as a new user, https://console.bluemix.net/docs/admin/profile.html#usersettings
*	How to create you account, https://knowledgelayer.softlayer.com/gettingstarted/how-to/set-your-account
*	How to create new user IDs, https://knowledgelayer.softlayer.com/procedure/add-new-user-customer-portal-account
*	Disk Configuration in New Orders, http://knowledgelayer.softlayer.com/articles/disk-configuration-new-orders
*	SoftLayer Design Decision Tool, http://knowledgelayer.softlayer.com/learning/softlayer-design-decision-tool#_Compute_1
*	IBM Cloud CDN, https://www.ibm.com/cloud-computing/bluemix/content-delivery-network
*	SoftLayer host and domain name rules, http://www.softlayer.com/diagrams/hostAndDomainRules
*	Additional information on ordering bare metal servers, http://knowledgelayer.softlayer.com/gettingstarted/how-to/set-bare-metal-server
*	Ordering Endurance for block and file storage, https://knowledgelayer.softlayer.com/procedure/endurance-provisioning
*	Ordering NAS, https://knowledgelayer.softlayer.com/procedure/order-nas-storage. Note that you must be logged in to SoftLayer to see the procedure.
    http://knowledgelayer.softlayer.com/procedure/mount-nas-storage-linux
    https://knowledgelayer.softlayer.com/procedure/connect-nas-storage-windows
*	Adding storage to ESXi-based servers, https://knowledgelayer.softlayer.com/procedure/mounting-iscsi-vmware-esxi
  https://knowledgelayer.softlayer.com/learning/architecture-guide-file-storage-vmware-softlayer
*	SAP Download Manager, https://support.sap.com/software/download-manager/help.html
